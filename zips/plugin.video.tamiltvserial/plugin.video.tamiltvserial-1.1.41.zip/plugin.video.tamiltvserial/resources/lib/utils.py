# -*- coding: utf-8 -*-

import html
import json
import re
import sys
import urllib.error
import urllib.parse
import urllib.request

from xbmcaddon import Addon
try:
    import xbmc
except ImportError:
    xbmc = None

from constants import ADDON_ID, API_URL, BASE_URL, USER_AGENT, WOODVIOLET_USER_AGENT


_addon = Addon()

_STRING_FALLBACKS = {
    30001: 'General',
    30002: 'Episodes per page',
    30003: 'Enable search',
    30010: 'Latest Episodes',
    30011: 'Browse by Channel',
    30012: 'Search',
    30013: 'Sun TV Serials',
    30014: 'Vijay TV Serials',
    30015: 'Zee Tamil Serials',
    30016: 'Tamil TV Shows',
    30017: 'Next page',
    30018: 'Enter search term',
    30019: 'No episodes found',
    30020: 'Could not resolve stream URL',
    30021: 'Resolving stream...',
    30022: 'Favorites',
    30023: 'Auto-play next episode',
    30031: 'Add to Favorites',
    30032: 'Remove from Favorites',
    30033: 'Added to favorites',
    30034: 'No favorites yet. Long-press a serial and choose Add to Favorites.',
    30035: 'Removed from favorites',
    30036: 'Playing next episode...',
    30037: 'Install InputStream Adaptive from Kodi\'s official add-on repository (VideoPlayer InputStream), then try again.',
    30038: 'InputStream Adaptive required',
    30039: 'Could not reach TamilTvSerial.com. Check your internet connection and try again.',
    30040: 'Something went wrong. Please try again.',
    30041: 'InputStream Adaptive is installed but disabled. Go to My add-ons → VideoPlayer InputStream → InputStream Adaptive → Enable.',
    30042: 'Connection Test',
    30043: 'Connection test passed',
    30044: 'Connection test failed',
    30045: 'Serials',
    30046: 'Shows',
    30047: 'This episode\'s stream host is temporarily unavailable. Try again later, or play a different serial.',
    30048: 'Playback start timeout (seconds)',
    30049: 'Trying alternate stream source...',
}


def encode_header_value(value):
    return urllib.parse.quote(str(value), safe='')


def set_list_label(list_item, label):
    if not label:
        return
    try:
        list_item.setLabel(label)
    except AttributeError:
        pass


def set_video_info(list_item, info_dict):
    try:
        info = list_item.getVideoInfoTag()
    except AttributeError:
        list_item.setInfo('video', info_dict)
        return

    title = info_dict.get('title')
    if title:
        info.setTitle(title)
    plot = info_dict.get('plot')
    if plot:
        info.setPlot(plot)
    media_type = info_dict.get('mediatype') or info_dict.get('media_type')
    if media_type:
        info.setMediaType(media_type)
    tvshowtitle = info_dict.get('tvshowtitle')
    if tvshowtitle:
        info.setTvShowTitle(tvshowtitle)
    episode = info_dict.get('episode')
    if episode is not None:
        info.setEpisode(episode)


def addon():
    return _addon


def localize(string_id):
    try:
        numeric_id = int(string_id)
    except (TypeError, ValueError):
        return str(string_id)

    value = _addon.getLocalizedString(numeric_id)
    if value:
        return value
    return _STRING_FALLBACKS.get(numeric_id, '')


def get_setting_int(setting_id, default=0):
    value = _addon.getSetting(setting_id)
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def get_setting_bool(setting_id, default=False):
    value = _addon.getSetting(setting_id)
    if value in ('true', '1'):
        return True
    if value in ('false', '0', ''):
        return default
    return default


def log(message, level=None):
    if level is None:
        level = getattr(xbmc, 'LOGINFO', 1)
    if xbmc and hasattr(xbmc, 'log'):
        xbmc.log(f'[{ADDON_ID}] {message}', level)
        return
    _addon.log(str(message), level)


def log_error(message):
    log(message, level=getattr(xbmc, 'LOGERROR', 4))


def build_plugin_url(base_url, **params):
    query = urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})
    return f'{base_url}?{query}' if query else base_url


def strip_html(text):
    if not text:
        return ''
    text = re.sub(r'<[^>]+>', ' ', text)
    return html.unescape(re.sub(r'\s+', ' ', text)).strip()


def request_url(url, params=None, referer=BASE_URL, method='GET', data=None, timeout=30):
    if params:
        query = urllib.parse.urlencode(params)
        url = f'{url}&{query}' if '?' in url else f'{url}?{query}'

    headers = {
        'User-Agent': USER_AGENT,
        'Accept': 'application/json, text/html, */*',
        'Referer': referer,
    }
    body = None
    if data is not None:
        body = json.dumps(data).encode('utf-8')
        headers['Content-Type'] = 'application/json'

    request = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = response.read()
            headers_out = dict(response.headers.items())
            return payload, headers_out, response.geturl()
    except urllib.error.HTTPError as exc:
        log_error(f'HTTP error {exc.code} for {url}')
        raise
    except urllib.error.URLError as exc:
        log_error(f'URL error for {url}: {exc.reason}')
        raise


def get_response_header(headers, name, default=''):
    if not headers:
        return default

    target = name.lower()
    for key, value in headers.items():
        if key.lower() == target:
            return value or default

    return default


def api_get(path, params=None):
    url = API_URL + path.lstrip('/')
    payload, headers, _final_url = request_url(url, params=params)
    data = json.loads(payload.decode('utf-8'))
    return data, headers


def get_featured_image(post):
    embedded = post.get('_embedded') or {}
    media_items = embedded.get('wp:featuredmedia') or []
    if not media_items:
        return ''
    media = media_items[0] or {}
    return media.get('source_url') or ''


def get_terms(post, taxonomy='category'):
    embedded = post.get('_embedded') or {}
    terms = embedded.get('wp:term') or []
    collected = []
    for group in terms:
        for term in group or []:
            if term.get('taxonomy') == taxonomy:
                collected.append(term.get('name', ''))
    return collected


def is_hls_url(url):
    lower = (url or '').lower()
    path = lower.split('?', 1)[0]
    return path.endswith('.m3u8') or '.m3u8' in path


def inputstream_adaptive_status():
    try:
        isa = Addon('inputstream.adaptive')
        enabled = isa.getAddonInfo('enabled')
        if enabled in ('false', '0', False):
            return 'disabled'
        return 'ready'
    except Exception as exc:
        log_error(f'InputStream Adaptive check failed: {exc}')
        return 'missing'


def playback_referer(referer):
    referer = (referer or BASE_URL).strip()
    lower = referer.lower()
    if 'vimeocdn.com' in lower:
        return 'https://player.vimeo.com/'
    if 'tamildhool' in lower or 'b-cdn.net' in lower:
        return 'https://www.tamildhool.tech/'
    return referer or BASE_URL


def _use_woodviolet_headers(referer=None, stream_url=None):
    referer_lower = (referer or '').lower()
    stream_lower = (stream_url or '').lower()
    if 'woodviolet.xyz' in referer_lower:
        return True
    return '/stream/variant/' in stream_lower and stream_lower.endswith('.m3u8')


def build_stream_headers(referer=None, cookies=None, stream_url=None):
    referer = playback_referer(referer)
    use_woodviolet = _use_woodviolet_headers(referer, stream_url)
    stream_lower = (stream_url or '').lower()
    user_agent = WOODVIOLET_USER_AGENT if use_woodviolet else USER_AGENT
    parts = [
        f'User-Agent={encode_header_value(user_agent)}',
        f'Referer={encode_header_value(referer)}',
    ]
    if use_woodviolet:
        parts.extend([
            'Origin=https%3A%2F%2Fwoodviolet.xyz',
            'Accept-Language=en-US%2Cen%3Bq%3D0.9',
        ])
    elif 'b-cdn.net' in stream_lower or 'tamildhool' in (referer or '').lower():
        # BunnyCDN rejects playlist/key/segment requests without these.
        parts.append('Origin=' + encode_header_value('https://www.tamildhool.tech'))
        parts.append('Accept=' + encode_header_value('*/*'))
    if cookies:
        parts.append(f'Cookie={encode_header_value(cookies)}')
    return '&'.join(parts)


def prefer_media_playlist(stream_url, referer=None, timeout=8):
    """If stream_url is an HLS master, return the first media playlist URL.

    BunnyCDN masters only list relative child playlists; resolving here keeps
    InputStream Adaptive on a single media playlist while still sending headers.
    """
    if not stream_url or not is_hls_url(stream_url):
        return stream_url
    if '/480p/' in stream_url or '/720p/' in stream_url or '/360p/' in stream_url:
        return stream_url

    headers = {
        'User-Agent': USER_AGENT,
        'Accept': '*/*',
        'Referer': playback_referer(referer),
    }
    if 'b-cdn.net' in stream_url.lower():
        headers['Origin'] = 'https://www.tamildhool.tech'
    try:
        request = urllib.request.Request(stream_url, headers=headers)
        context = None
        try:
            import ssl
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        except Exception:
            context = None
        with urllib.request.urlopen(request, timeout=timeout, context=context) as response:
            body = response.read(4096).decode('utf-8', 'replace')
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError, TypeError):
        # TypeError: older Python urlopen without context kwarg
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                body = response.read(4096).decode('utf-8', 'replace')
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError):
            return stream_url

    if '#EXT-X-STREAM-INF' not in body:
        return stream_url

    base = stream_url.rsplit('/', 1)[0] + '/'
    for line in body.splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        child = line if line.startswith('http') else urllib.parse.urljoin(base, line)
        if is_hls_url(child) or child.endswith('.m3u8'):
            return child
    return stream_url


def apply_stream_properties(list_item, stream_url, referer=None, cookies=None):
    """Configure ListItem for playback. For ISA, never put |headers on the path."""
    referer = playback_referer(referer)
    if is_hls_url(stream_url) and 'b-cdn.net' in stream_url.lower():
        stream_url = prefer_media_playlist(stream_url, referer=referer)

    headers = build_stream_headers(referer, cookies=cookies, stream_url=stream_url)

    if is_hls_url(stream_url):
        # InputStream Adaptive does NOT support URL|header=value pipe syntax.
        list_item.setPath(stream_url)
        list_item.setMimeType('application/vnd.apple.mpegurl')
        try:
            list_item.setContentLookup(False)
        except Exception:
            pass
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        list_item.setProperty('inputstream.adaptive.manifest_headers', headers)
        list_item.setProperty('inputstream.adaptive.stream_headers', headers)
        list_item.setProperty('inputstream.adaptive.common_headers', headers)
        list_item.setProperty('inputstream.adaptive.is_realtime_stream', 'false')
        # BunnyCDN AES-128 key requests are separate from stream GETs and also
        # require Referer; without this, manifests resolve then playback stalls.
        list_item.setProperty('inputstream.adaptive.license_key', '|' + headers)
        try:
            drm_cfg = {'none': {'license': {'req_headers': headers}}}
            list_item.setProperty('inputstream.adaptive.drm', json.dumps(drm_cfg))
        except Exception as exc:
            log_error(f'Failed to set ISA DRM key headers: {exc}')
        return

    playback_url = f'{stream_url}|{headers}' if headers else stream_url
    list_item.setPath(playback_url)
    try:
        if stream_url.lower().split('?', 1)[0].endswith('.mp4'):
            list_item.setMimeType('video/mp4')
            return
    except Exception as exc:
        log_error(f'Failed to set stream properties: {exc}')
