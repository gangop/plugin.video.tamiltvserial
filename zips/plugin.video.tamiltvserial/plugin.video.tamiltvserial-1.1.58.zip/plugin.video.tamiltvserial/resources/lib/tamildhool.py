# -*- coding: utf-8 -*-

import json
import os
import re
import ssl
import time
import urllib.error
import urllib.request

from constants import WOODVIOLET_USER_AGENT
from utils import log, log_error, strip_html


TAMILDHOOL_BASE = 'https://www.tamildhool.tech'
# Prefer jsDelivr on Google TV (raw.githubusercontent.com is often blocked/cached).
# GitHub raw remains as a secondary mirror.
FALLBACK_INDEX_URLS = (
    'https://cdn.jsdelivr.net/gh/gangop/plugin.video.tamiltvserial@main/fallback/tamildhool.json',
    'https://raw.githubusercontent.com/gangop/plugin.video.tamiltvserial/main/fallback/tamildhool.json',
)
SHOW_ALIASES_URLS = (
    'https://cdn.jsdelivr.net/gh/gangop/plugin.video.tamiltvserial@main/fallback/show_aliases.json',
    'https://raw.githubusercontent.com/gangop/plugin.video.tamiltvserial/main/fallback/show_aliases.json',
)
# How long the in-memory episode index may be reused before re-fetching from GitHub.
INDEX_CACHE_TTL_SECONDS = 3600
TITLE_DATE_PATTERN = re.compile(r'(\d{1,2})-(\d{1,2})-(\d{4})')
EPISODE_NUMBER_PATTERN = re.compile(r'Episode\s+(\d+)', re.I)
BUNNY_PATTERN = re.compile(
    r'https://(vz-[a-z0-9-]+\.b-cdn\.net)/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/',
    re.I,
)
DAILYMOTION_PATTERN = re.compile(
    r'(?:dai\.ly/|dailymotion\.com/(?:embed/)?video/)([A-Za-z0-9]+)',
    re.I,
)
TEAMSTODAY_PATTERN = re.compile(
    r'teamstoday\.com/\?video=([A-Za-z0-9]+)',
    re.I,
)
CHANNEL_SLUGS = (
    ('sun tv', 'sun-tv'),
    ('vijay tv', 'vijay-tv'),
    ('zee tamil', 'zee-tamil'),
)

# Built-in show-level aliases (folder names). Episode streams are NOT stored here —
# those come from the CI-generated tamildhool.json for every serial/show.
_BUILTIN_SHOW_ALIASES = {
    'pudhu-vasantham': ('pudhu-vasantham', 'puthu-vasantham'),
    'sindhu-bairavi': ('sindhu-bairavi-kacheri-arambam',),
    'onna-irukka-kaththukanum': ('onna-irukka-kaththukkanum',),
    'startup-singam': ('startup-singam-s2',),
    'anda-ka-kasam': ('anda-ka-kasam-s4',),
    'andakakasam': ('anda-ka-kasam-s4',),
    'jodi-are-u-ready': ('jodi-are-u-ready-s3',),
    'jodi-are-u-ready-season-3': ('jodi-are-u-ready-s3',),
    'paarijatham': ('parijatham',),
    'chinnan-siru-kiliye': ('chinna-siru-kiliye',),
    'saregamapa-lil-champs-season-5': ('saregamapa-little-champs-s5',),
    'tamizha-tamizha': ('tamizha-tamizha-s3',),
    'mahanadigai': ('mahanadigai-s2',),
    'ethirneechal': ('ethir-neechal-thodargirathu', 'ethir-neechal', 'ethirneechal'),
    'ethir-neechal': ('ethir-neechal-thodargirathu', 'ethir-neechal', 'ethirneechal'),
    'chamanthi': ('samanthi',),
    'samanthi': ('samanthi',),
    'moondru-mudichu': ('moondru-mudichi', 'moondru-mudichu'),
    'pandian-stores': ('pandian-stores-s-2', 'pandian-stores'),
    'singappenne': ('singappenne', 'singapenne'),
}

# Prefer GitHub raw for freshness; jsDelivr @main can lag and omit recent_episodes.
# load_active_serials() still tries every mirror and keeps the richest catalog.
ACTIVE_SERIALS_URLS = (
    'https://raw.githubusercontent.com/gangop/plugin.video.tamiltvserial/main/fallback/active_serials.json',
    'https://cdn.jsdelivr.net/gh/gangop/plugin.video.tamiltvserial@main/fallback/active_serials.json',
)

_index_cache = {'data': None, 'fetched_at': 0.0}
_aliases_cache = {'data': None}
_active_serials_cache = {'data': None, 'fetched_at': 0.0}


def _slugify(value):
    value = re.sub(r'[^a-z0-9]+', '-', (value or '').lower()).strip('-')
    return re.sub(r'-{2,}', '-', value)


def _normalize_date(day, month, year):
    return f'{int(day):02d}-{int(month):02d}-{year}'


def parse_episode_meta(title):
    """Return (show, date DD-MM-YYYY, channel_name, episode_number)."""
    title = strip_html(title or '')
    if not title:
        return '', '', '', None

    date_match = TITLE_DATE_PATTERN.search(title)
    date = ''
    if date_match:
        date = _normalize_date(date_match.group(1), date_match.group(2), date_match.group(3))

    episode_number = None
    episode_match = EPISODE_NUMBER_PATTERN.search(title)
    if episode_match:
        episode_number = int(episode_match.group(1))

    channel = ''
    lower = title.lower()
    for name, _channel_slug in CHANNEL_SLUGS:
        if name in lower:
            channel = name
            break

    show = title
    if '|' in show:
        show = show.split('|', 1)[0]
    show = TITLE_DATE_PATTERN.sub('', show)
    show = re.sub(r'\s+', ' ', show).strip(' -|')
    return show, date, channel, episode_number


def _is_show_title(title):
    return 'tv show' in (title or '').lower()


def _channel_entry(channel_name, title=''):
    for name, channel_slug in CHANNEL_SLUGS:
        if name == channel_name:
            kind = 'show' if _is_show_title(title) else 'serial'
            return channel_slug, f'{channel_slug}-{kind}'
    return '', ''


def episode_index_key(title):
    show, date, channel, _episode_number = parse_episode_meta(title)
    channel_slug, _kind_slug = _channel_entry(channel, title)
    if not show or not date or not channel_slug:
        return ''
    return f'{channel_slug}/{_slugify(show)}/{date}'


def _find_crossover_index_entry(index, channel_slug, show_slug, date):
    """Find a same-date index entry whose TamilDhool page also covers this show.

    Used for mahasangamam / crossover uploads that live under a partner show folder
    (e.g. Lakshmi–Iru Malargal Mahasangamam indexed under lakshmi/).
    """
    if not index or not channel_slug or not show_slug or not date:
        return '', {}

    prefix = f'{channel_slug}/'
    suffix = f'/{date}'
    exact = f'{channel_slug}/{show_slug}/{date}'
    for key, entry in index.items():
        if key == exact or not isinstance(entry, dict):
            continue
        if not key.startswith(prefix) or not key.endswith(suffix):
            continue
        if not (entry.get('stream') or entry.get('dailymotion')):
            continue
        page = (entry.get('page') or '').lower()
        if not page:
            continue
        basename = page.rstrip('/').rsplit('/', 1)[-1]
        # Require the show slug inside the episode URL slug (not just folder).
        if show_slug in basename:
            return key, entry
    return '', {}


def _lookup_index_entry(title):
    """Exact episode key, then same-date crossover/mahasangamam mirror."""
    key = episode_index_key(title)
    index = _load_fallback_index()
    if not key:
        return '', {}

    entry = index.get(key) or {}
    if isinstance(entry, dict) and (entry.get('stream') or entry.get('dailymotion')):
        return key, entry

    show, date, channel, _episode_number = parse_episode_meta(title)
    channel_slug, _kind = _channel_entry(channel, title)
    if not show or not date or not channel_slug:
        return key, {}

    alt_key, alt_entry = _find_crossover_index_entry(
        index, channel_slug, _slugify(show), date,
    )
    if alt_entry:
        log(f'TamilDhool crossover index hit {key} via {alt_key}')
        return alt_key, alt_entry
    return key, {}


def _path_slugs(show_slug):
    """Return (folder_slug, episode_slug_bases) for TamilDhool URLs."""
    aliases = _show_path_aliases().get(show_slug)
    if not aliases:
        return show_slug, [show_slug]
    folder_slug = aliases[0]
    episode_bases = []
    for alias in aliases:
        if alias and alias not in episode_bases:
            episode_bases.append(alias)
    if folder_slug not in episode_bases:
        episode_bases.insert(0, folder_slug)
    return folder_slug, episode_bases


def _show_path_aliases():
    """Show-level folder aliases (stable). Loaded from GitHub when possible."""
    if _aliases_cache['data'] is not None:
        return _aliases_cache['data']

    aliases = dict(_BUILTIN_SHOW_ALIASES)
    for url in SHOW_ALIASES_URLS:
        request = urllib.request.Request(
            url,
            headers={
                'User-Agent': WOODVIOLET_USER_AGENT,
                'Accept': 'application/json',
                'Cache-Control': 'no-cache',
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=10, context=_ssl_context()) as response:
                data = json.loads(response.read().decode('utf-8', 'replace'))
            if isinstance(data, dict):
                for key, value in data.items():
                    if isinstance(value, list) and value:
                        aliases[str(key)] = tuple(str(part) for part in value if part)
                break
        except (
            urllib.error.URLError,
            urllib.error.HTTPError,
            TimeoutError,
            OSError,
            ValueError,
        ) as exc:
            log(f'TamilDhool show aliases unavailable from {url}: {exc}')

    _aliases_cache['data'] = aliases
    return aliases


def build_episode_urls(title):
    """Build exact TamilDhool episode URLs for this show/date/channel."""
    show, date, channel, _episode_number = parse_episode_meta(title)
    if not show or not date or not channel:
        log(
            'TamilDhool: need show, date, and channel for exact match '
            f'(show={show!r}, date={date!r}, channel={channel!r})'
        )
        return []

    channel_slug, kind_slug = _channel_entry(channel, title)
    if not channel_slug:
        return []

    show_slug = _slugify(show)
    folder_slug, episode_bases = _path_slugs(show_slug)
    urls = []
    for episode_slug_base in episode_bases:
        episode_slug = f'{episode_slug_base}-{date}-{kind_slug}'
        urls.append(
            f'{TAMILDHOOL_BASE}/{channel_slug}/{kind_slug}/{folder_slug}/{episode_slug}/'
        )
        # Some older pages omit the trailing kind suffix.
        urls.append(
            f'{TAMILDHOOL_BASE}/{channel_slug}/{kind_slug}/{folder_slug}/'
            f'{episode_slug_base}-{date}/'
        )
    return urls


def _discover_episode_urls(title):
    """Find dated TamilDhool episode links from the show folder."""
    show, date, channel, _episode_number = parse_episode_meta(title)
    if not show or not date or not channel:
        return []

    channel_slug, kind_slug = _channel_entry(channel, title)
    if not channel_slug:
        return []

    show_slug = _slugify(show)
    folder_slug, _episode_bases = _path_slugs(show_slug)
    show_index = f'{TAMILDHOOL_BASE}/{channel_slug}/{kind_slug}/{folder_slug}/'

    log(f'TamilDhool discovering episode links from: {show_index}')
    try:
        final_url, html = _fetch_page(show_index)
    except urllib.error.HTTPError as exc:
        log_error(f'TamilDhool listing fetch failed for {show_index}: HTTP {exc.code}')
        return []
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        log_error(f'TamilDhool listing fetch failed for {show_index}: {exc}')
        return []

    if _is_challenge_page(html):
        log_error('TamilDhool listing returned a Cloudflare challenge page')
        return []

    base_path = f'{channel_slug}/{kind_slug}/{folder_slug}/'
    pattern = re.compile(
        rf'https://www\.tamildhool\.tech/{re.escape(base_path)}[^"\']+-'
        rf'{re.escape(date)}[^"\']*/',
        re.I,
    )
    urls = []
    seen = set()
    for url in pattern.findall(html or ''):
        clean_url = url.rstrip('/') + '/'
        if clean_url not in seen:
            seen.add(clean_url)
            urls.append(clean_url)

    if urls:
        log(f'TamilDhool discovered {len(urls)} dated episode link(s) from {final_url}')
    return urls



def _ssl_context():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def _is_challenge_page(html):
    lower = (html or '').lower()
    if '<title>just a moment...</title>' in lower:
        return True
    if 'just a moment' in lower and 'enable javascript and cookies to continue' in lower:
        return True
    return False


def _page_matches_episode(final_url, html, show, date, channel, title=''):
    show_slug = _slugify(show)
    channel_slug, kind_slug = _channel_entry(channel, title or show)
    if not show_slug or not date or not channel_slug:
        return False

    folder_slug, episode_bases = _path_slugs(show_slug)
    url_lower = (final_url or '').lower().rstrip('/') + '/'
    if f'/{channel_slug}/' not in url_lower or f'/{folder_slug}/' not in url_lower:
        return False

    matched_path = False
    for episode_slug_base in episode_bases:
        expected_tail = f'/{folder_slug}/{episode_slug_base}-{date}-{kind_slug}/'
        alt_tail = f'/{folder_slug}/{episode_slug_base}-{date}/'
        if expected_tail in url_lower or alt_tail in url_lower:
            matched_path = True
            break
    if not matched_path and f'/{folder_slug}/' in url_lower and f'-{date}' in url_lower:
        # Discovered TamilDhool links can include suffixes such as grand-finale or
        # full-episode between the date and the kind tag.
        matched_path = True
    if not matched_path:
        return False

    title_match = re.search(r'<title[^>]*>(.*?)</title>', html or '', re.I | re.S)
    page_title = strip_html(title_match.group(1) if title_match else '')
    page_lower = page_title.lower()
    # Alias folders (e.g. Andakakasam -> Anda Ka Kasam) may not contain the TTS title.
    if show.lower() not in page_lower and folder_slug.replace('-', ' ') not in page_lower:
        return False
    if date not in page_title and date not in (html or '')[:4000]:
        return False
    if channel not in page_lower and channel_slug.replace('-', ' ') not in page_lower:
        return False
    return True


def _fetch_page(url, timeout=20):
    headers = {
        'User-Agent': WOODVIOLET_USER_AGENT,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer': TAMILDHOOL_BASE + '/',
    }
    request = urllib.request.Request(url, headers=headers)
    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=_ssl_context()))
    with opener.open(request, timeout=timeout) as response:
        html = response.read().decode('utf-8', 'replace')
        return response.geturl(), html


def _fetch_json_url(base_url, label):
    """Fetch one JSON dict from a published URL, or None on failure."""
    cache_bust = int(time.time() // 3600)
    url = f'{base_url}?v={cache_bust}'
    request = urllib.request.Request(
        url,
        headers={
            'User-Agent': WOODVIOLET_USER_AGENT,
            'Accept': 'application/json',
            'Cache-Control': 'no-cache',
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=15, context=_ssl_context()) as response:
            data = json.loads(response.read().decode('utf-8', 'replace'))
    except (
        urllib.error.URLError,
        urllib.error.HTTPError,
        TimeoutError,
        OSError,
        ValueError,
    ) as exc:
        log_error(f'{label} unavailable from {url}: {exc}')
        return None

    if isinstance(data, dict) and data:
        log(f'{label} loaded from {base_url.split("/")[2]}')
        return data
    return None


def _fetch_json_urls(urls, label):
    """Fetch the first usable JSON dict from a list of published URLs."""
    for base_url in urls:
        data = _fetch_json_url(base_url, label)
        if data is not None:
            return data
    return None


def _active_serials_score(data):
    """Prefer catalogs that include recent_episodes (needed to list TD-ahead dates)."""
    if not isinstance(data, dict) or not data.get('channels'):
        return (-1, '')
    episode_count = 0
    for entries in (data.get('channels') or {}).values():
        if not isinstance(entries, list):
            continue
        for entry in entries:
            if isinstance(entry, dict):
                episode_count += len(entry.get('recent_episodes') or [])
    return (episode_count, data.get('updated') or '')


def _load_fallback_index():
    """Load CI-generated episode→stream map for all shows (refreshed on a TTL)."""
    now = time.time()
    cached = _index_cache['data']
    fetched_at = _index_cache.get('fetched_at') or 0.0
    if cached is not None and (now - fetched_at) < INDEX_CACHE_TTL_SECONDS:
        return cached

    data = _fetch_json_urls(FALLBACK_INDEX_URLS, 'TamilDhool fallback index')
    if isinstance(data, dict) and data:
        log(f'TamilDhool index loaded ({len(data)} episodes)')
        _index_cache['data'] = data
        _index_cache['fetched_at'] = now
        return data

    # Don't cache failures — allow a later play attempt to retry.
    return cached if isinstance(cached, dict) else {}


def _bundled_active_serials_path():
    # resources/lib/tamildhool.py → resources/data/active_serials.json
    return os.path.join(os.path.dirname(__file__), '..', 'data', 'active_serials.json')


def _load_bundled_active_serials():
    path = _bundled_active_serials_path()
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
    except (OSError, ValueError) as exc:
        log_error(f'Bundled active serials unavailable: {exc}')
        return None
    return data if isinstance(data, dict) and data.get('channels') else None


def load_active_serials(channel_id=None):
    """Return TamilDhool-driven serial menu entries for a TTS channel parent id.

    Tries every published mirror plus the addon bundle and keeps the catalog
    with the most recent_episodes (jsDelivr @main can serve a stale copy that
    still has latest_date but empty episode lists). Returns an empty list when
    nothing usable is available so the caller can fall back to live TTS.
    """
    now = time.time()
    cached = _active_serials_cache['data']
    fetched_at = _active_serials_cache.get('fetched_at') or 0.0
    if cached is None or (now - fetched_at) >= INDEX_CACHE_TTL_SECONDS:
        candidates = []
        for base_url in ACTIVE_SERIALS_URLS:
            data = _fetch_json_url(base_url, 'TamilDhool active serials')
            if isinstance(data, dict) and data.get('channels'):
                candidates.append(data)
        bundled = _load_bundled_active_serials()
        if bundled:
            candidates.append(bundled)
            log('TamilDhool active serials candidate from addon bundle')

        data = None
        if candidates:
            data = max(candidates, key=_active_serials_score)
            score, updated = _active_serials_score(data)
            log(
                f'TamilDhool active serials selected '
                f'({score} recent episodes, updated {updated or "unknown"})'
            )

        if isinstance(data, dict) and data.get('channels'):
            _active_serials_cache['data'] = data
            _active_serials_cache['fetched_at'] = now
            cached = data
        elif not isinstance(cached, dict):
            return []

    channels = (cached or {}).get('channels') or {}
    if channel_id is None:
        return channels
    entries = channels.get(str(channel_id)) or channels.get(channel_id) or []
    return entries if isinstance(entries, list) else []


def resolve_from_fallback_index(title):
    """Resolve exact episode from the published GitHub index (no Cloudflare)."""
    key, entry = _lookup_index_entry(title)
    if not key:
        return '', '', ''

    stream_url = entry.get('stream') or ''
    if stream_url:
        # BunnyCDN requires a tamildhool.tech Referer on every playlist/segment request.
        if 'b-cdn.net' in stream_url.lower():
            referer = TAMILDHOOL_BASE + '/'
        else:
            referer = entry.get('referer') or entry.get('page') or (TAMILDHOOL_BASE + '/')
        log(f'TamilDhool index hit for {key}: {stream_url}')
        return stream_url, referer, ''

    video_id = entry.get('dailymotion') or ''
    if video_id:
        stream_url, referer = resolve_dailymotion_stream(video_id)
        if stream_url:
            log(f'TamilDhool index Dailymotion hit for {key}')
            return stream_url, referer, ''

    log(f'TamilDhool index miss for {key}')
    return '', '', ''


def extract_bunny_playlists(html):
    playlists = []
    seen = set()
    for host, video_id in BUNNY_PATTERN.findall(html or ''):
        playlist = f'https://{host}/{video_id}/playlist.m3u8'
        if playlist not in seen:
            seen.add(playlist)
            playlists.append(playlist)
    return playlists


def extract_dailymotion_ids(html):
    ids = []
    seen = set()
    for match in DAILYMOTION_PATTERN.findall(html or ''):
        video_id = match if isinstance(match, str) else next((part for part in match if part), '')
        if video_id and video_id not in seen:
            seen.add(video_id)
            ids.append(video_id)
    # Newer TamilDhool cards wrap Dailymotion ids in teamstoday.com links.
    for video_id in TEAMSTODAY_PATTERN.findall(html or ''):
        if video_id.startswith('k') and len(video_id) >= 10 and video_id not in seen:
            seen.add(video_id)
            ids.append(video_id)
    return ids


def resolve_dailymotion_stream(video_id):
    if not video_id:
        return '', ''

    metadata_url = f'https://www.dailymotion.com/player/metadata/video/{video_id}'
    headers = {
        'User-Agent': WOODVIOLET_USER_AGENT,
        'Accept': 'application/json',
        'Referer': 'https://www.dailymotion.com/',
    }
    request = urllib.request.Request(metadata_url, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=15, context=_ssl_context()) as response:
            data = json.loads(response.read().decode('utf-8', 'replace'))
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError, ValueError) as exc:
        log_error(f'Dailymotion metadata failed for {video_id}: {exc}')
        return '', ''

    qualities = data.get('qualities') or {}
    auto = qualities.get('auto') or []
    if auto and isinstance(auto, list):
        stream_url = (auto[0] or {}).get('url') or ''
        if stream_url:
            return stream_url, 'https://www.dailymotion.com/'
    return '', ''


def resolve_tamildhool_stream(title, use_index=True):
    """Resolve the exact same episode via published index, then live page fetch."""
    show, date, channel, episode_number = parse_episode_meta(title)
    log(
        'TamilDhool exact episode: '
        f'show={show!r} date={date} channel={channel} episode={episode_number}'
    )

    if use_index:
        stream_url, referer, cookies = resolve_from_fallback_index(title)
        if stream_url:
            return stream_url, referer, cookies

    urls = build_episode_urls(title)
    if not urls:
        return '', '', ''

    seen_urls = set(urls)
    for discovered_url in _discover_episode_urls(title):
        if discovered_url not in seen_urls:
            seen_urls.add(discovered_url)
            urls.append(discovered_url)

    for page_url in urls:
        log(f'TamilDhool fetching exact URL: {page_url}')
        try:
            final_url, html = _fetch_page(page_url)
        except urllib.error.HTTPError as exc:
            log_error(f'TamilDhool fetch failed for {page_url}: HTTP {exc.code}')
            continue
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            log_error(f'TamilDhool fetch failed for {page_url}: {exc}')
            continue

        if _is_challenge_page(html):
            log_error('TamilDhool returned a Cloudflare challenge page')
            continue
        if not html:
            continue

        if not _page_matches_episode(final_url, html, show, date, channel, title):
            log_error(
                f'TamilDhool page did not match selected episode '
                f'(wanted {show} {date} {channel}, got {final_url})'
            )
            continue

        bunny_urls = extract_bunny_playlists(html)
        if bunny_urls:
            stream_url = bunny_urls[0]
            log(f'TamilDhool BunnyCDN stream for exact episode: {stream_url}')
            return stream_url, final_url, ''

        for video_id in extract_dailymotion_ids(html):
            stream_url, dm_referer = resolve_dailymotion_stream(video_id)
            if stream_url:
                log(f'TamilDhool Dailymotion stream for exact episode: {stream_url}')
                return stream_url, dm_referer or final_url, ''

        log(f'TamilDhool exact page had no playable sources: {final_url}')

    return '', '', ''
